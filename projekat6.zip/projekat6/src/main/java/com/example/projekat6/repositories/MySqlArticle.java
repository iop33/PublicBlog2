package com.example.projekat6.repositories;

import com.example.projekat6.entities.Article;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySqlArticle extends MySqlAbstractRepository implements ArticleRepository {


    @Override
    public Article dodavanjePosta(Article article) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();

            String[] generatedColumns = {"id"};

            preparedStatement = connection.prepareStatement("INSERT INTO post (tekst, autor,datum,naslov) VALUES(?, ?,?,?)", generatedColumns);
            preparedStatement.setString(1, article.getText());
            preparedStatement.setString(2, article.getAutor());
            preparedStatement.setString(3, article.getDatum());
            preparedStatement.setString(4, article.getTitle());
            preparedStatement.executeUpdate();
            resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {
                article.setId(resultSet.getInt(1));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return article;
    }

    @Override
    public List<Article> pregledPostova() {
        List<Article> articles = new ArrayList<>();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();

            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from post");
            while (resultSet.next()) {
                articles.add(new Article(resultSet.getInt("id"), resultSet.getString("naslov"), resultSet.getString("tekst"), resultSet.getString("autor")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(statement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return articles;
    }



    @Override
    public Article pregledPojedinacnogPosta(Integer id) {
        Article article = null;

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();

            preparedStatement = connection.prepareStatement("SELECT * FROM post where id = ?");
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();

            if(resultSet.next()) {
                int subjectId = resultSet.getInt("id");
                String title = resultSet.getString("naslov");
                String tekst = resultSet.getString("tekst");
                String autor = resultSet.getString("autor");
                article = new Article(subjectId, title, tekst,autor);
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return article;
    }


}
