package com.example.projekat6.repositories.comment;

import com.example.projekat6.entities.Article;
import com.example.projekat6.entities.Comment;
import com.example.projekat6.repositories.ArticleRepository;
import com.example.projekat6.repositories.MySqlAbstractRepository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySqlComment extends MySqlAbstractRepository implements CommentRepository {


    @Override
    public Comment dodajKomentar(Comment comment) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();

            String[] generatedColumns = {"id"};

            preparedStatement = connection.prepareStatement("INSERT INTO komentar (tekst,postId,autor) VALUES(?, ?,?)", generatedColumns);
            preparedStatement.setString(1, comment.getTekst());
            preparedStatement.setInt(2, comment.getPostId());
            preparedStatement.setString(3,comment.getAutor());
            preparedStatement.executeUpdate();
            resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {
                comment.setId(resultSet.getInt(1));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(preparedStatement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return comment;
    }

    @Override
    public List<Comment> pregledSvihKomentara(Integer postId) {
        List<Comment> comments = new ArrayList<>();

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try {
            connection = this.newConnection();

            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from komentar where postId="+postId);
            while (resultSet.next()) {
                comments.add(new Comment(resultSet.getInt("id"),  resultSet.getString("tekst"),resultSet.getInt("postId"), resultSet.getString("autor")));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.closeStatement(statement);
            this.closeResultSet(resultSet);
            this.closeConnection(connection);
        }

        return comments;
    }
}
