package com.example.projekat6;

import com.example.projekat6.repositories.ArticleRepository;
import com.example.projekat6.repositories.MySqlArticle;
import com.example.projekat6.repositories.comment.CommentRepository;
import com.example.projekat6.repositories.comment.MySqlComment;
import com.example.projekat6.repositories.user.InMemoryUserRepository;
import com.example.projekat6.repositories.user.UserRepository;
import com.example.projekat6.servicies.ArticleService;
import com.example.projekat6.servicies.CommentService;
import com.example.projekat6.servicies.UserService;
import org.glassfish.jersey.internal.inject.AbstractBinder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;

import javax.inject.Singleton;
import javax.ws.rs.ApplicationPath;

@ApplicationPath("/api")
public class HelloApplication extends ResourceConfig {
    public HelloApplication(){
        property(ServerProperties.BV_SEND_ERROR_IN_RESPONSE, true);

        AbstractBinder binder = new AbstractBinder() {
            @Override
            protected void configure() {
                this.bind(MySqlArticle.class).to(ArticleRepository.class).in(Singleton.class);
                this.bind(MySqlComment.class).to(CommentRepository.class).in(Singleton.class);
                this.bind(InMemoryUserRepository.class).to(UserRepository.class).in(Singleton.class);

                this.bindAsContract(ArticleService.class);
                this.bindAsContract(CommentService.class);
                this.bindAsContract(UserService.class);
                //this.bindAsContract(AuthFilter.class);


            }
        };
        register(binder);
        packages("com.example.projekat6");
    }

}