package com.example.projekat6.servicies;

import com.example.projekat6.entities.Article;
import com.example.projekat6.entities.Comment;
import com.example.projekat6.repositories.ArticleRepository;
import com.example.projekat6.repositories.comment.CommentRepository;

import javax.inject.Inject;
import java.util.List;

public class CommentService {

    @Inject
    private CommentRepository commentRepository;
    /*
    public Article dodavanjePosta(Article article);
    public List<Article> pregledPostova();
    public void dodavanjeKomentara(String ime,String komentar,Integer id);
    public Article pregledPojedinacnogPosta(Integer id);
     */
    public Comment dodajKomentar(Comment comment){return this.commentRepository.dodajKomentar(comment);}
    public List<Comment> pregledSvihKomentara(Integer postId){return this.commentRepository.pregledSvihKomentara(postId);}


}
