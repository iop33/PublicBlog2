package com.example.projekat6.entities;

public class Comment {
    private Integer id;
    private String tekst;
    private Integer postId;
    private String autor;

    public Comment(){

    }
    public Comment(Integer id, String tekst, Integer postId, String autor) {
        this();
        this.id=id;
        this.tekst = tekst;
        this.postId = postId;
        this.autor = autor;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTekst() {
        return tekst;
    }

    public void setTekst(String tekst) {
        this.tekst = tekst;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }
}
