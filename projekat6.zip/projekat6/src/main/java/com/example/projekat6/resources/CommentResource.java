package com.example.projekat6.resources;

import com.example.projekat6.entities.Article;
import com.example.projekat6.entities.Comment;
import com.example.projekat6.servicies.ArticleService;
import com.example.projekat6.servicies.CommentService;

import javax.inject.Inject;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/comments")
public class CommentResource {

    @Inject
    private CommentService commentService;

    @GET
    @Path("/{postId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response all(@PathParam("postId") Integer postId){return Response.ok(this.commentService.pregledSvihKomentara(postId)).build();}

    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Comment create(@Valid Comment comment){ return this.commentService.dodajKomentar(comment);}


}
