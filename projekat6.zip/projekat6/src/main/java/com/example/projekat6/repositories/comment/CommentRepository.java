package com.example.projekat6.repositories.comment;

import com.example.projekat6.entities.Comment;

import java.util.List;

public interface CommentRepository {

    public Comment dodajKomentar(Comment comment);
    public List<Comment> pregledSvihKomentara(Integer postId);

}
