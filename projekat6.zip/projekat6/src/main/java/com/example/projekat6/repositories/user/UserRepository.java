package com.example.projekat6.repositories.user;


import com.example.projekat6.entities.User;

public interface UserRepository {
    public User findUser(String username);
}
