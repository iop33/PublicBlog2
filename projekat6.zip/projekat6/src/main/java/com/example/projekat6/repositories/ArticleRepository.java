package com.example.projekat6.repositories;

import com.example.projekat6.entities.Article;

import java.util.List;

public interface ArticleRepository {


    public Article dodavanjePosta(Article article);
    public List<Article> pregledPostova();
    public Article pregledPojedinacnogPosta(Integer id);




}
