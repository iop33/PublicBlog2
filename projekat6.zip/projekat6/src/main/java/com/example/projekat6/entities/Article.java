package com.example.projekat6.entities;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class Article {

    private Integer id;
    @NotNull
    @NotEmpty(message="this field is required")
    private String title;
    @NotNull
    @NotEmpty(message="this field is required")
    private String text;
    private String datum;
    @NotNull
    @NotEmpty(message="this field is required")
    private String autor;


    public Article() {
        this.datum= LocalDate.now().toString();

    }

    public Article(Integer id, String title, String text, String autor) {
        this();
        this.id = id;
        this.title = title;
        this.text = text;
        this.autor = autor;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }


}
